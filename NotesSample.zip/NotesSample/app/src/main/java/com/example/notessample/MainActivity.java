package com.example.notessample;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText editText;
    private Button saveButton;
    private ListView listView;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> notes;
    private MyDataBase myDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText = findViewById(R.id.edit_text);
        saveButton = findViewById(R.id.save_button);
        listView = findViewById(R.id.myListView);
        notes = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, notes);
        listView.setAdapter(adapter);

        myDB = new MyDataBase(this);

        registerForContextMenu(listView);

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String note = editText.getText().toString().trim();
                if (!note.isEmpty()) {
                    myDB.insertData(note);
                    displayData();
                    editText.getText().clear();
                }
            }
        });

        displayData();
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.add(Menu.NONE, Menu.FIRST, Menu.NONE, "Видалити");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
        switch (item.getItemId()) {
            case Menu.FIRST:
                Cursor cursor = myDB.getAllData();
                if (cursor.moveToPosition(info.position)) {
                    @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex(MyDataBase.COL_ID));
                    myDB.deleteData(id);
                    displayData();
                }
                return true;
            default:
                return super.onContextItemSelected(item);
        }
    }

    private void displayData() {
        notes.clear();
        Cursor cursor = myDB.getAllData();
        if (cursor.moveToFirst()) {
            do {
                notes.add(cursor.getString(1));
            } while (cursor.moveToNext());
        }
        adapter.notifyDataSetChanged();
    }

    static class MyDataBase extends SQLiteOpenHelper {
        private static final String DATABASE_NAME = "notes.db";
        private static final String TABLE_NAME = "notes_table";
        private static final String COL_ID = "_id";
        private static final String COL_NOTE = "note";
        private static final int DATABASE_VERSION = 1;

        MyDataBase(Context context) {
            super(context, DATABASE_NAME, null, DATABASE_VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE " + TABLE_NAME + " (" +
                    COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COL_NOTE + " TEXT)");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
            onCreate(db);
        }

        public boolean insertData(String note) {
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(COL_NOTE, note);
            long result = db.insert(TABLE_NAME, null, contentValues);
            return result != -1;
        }

        public Cursor getAllData() {
            SQLiteDatabase db = this.getWritableDatabase();
            return db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        }

        public boolean deleteData(long id) {
            SQLiteDatabase db = this.getWritableDatabase();
            return db.delete(TABLE_NAME, COL_ID + "=" + id, null) > 0;
        }
    }
}
